
Note:
  keep the path name as server, other wise upload can't work.

command line usage:
 python uploader.py <appid> <email> <password> <rc4-password>

 appid support combind multi appid with |, like appid1|appid2|appid3

