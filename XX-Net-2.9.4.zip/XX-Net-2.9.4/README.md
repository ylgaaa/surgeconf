[中文文档](https://github.com/XX-net/XX-Net/wiki/%E4%B8%AD%E6%96%87%E6%96%87%E6%A1%A3)

[English Home](https://github.com/XX-net/XX-Net/wiki/English-Home-Page)  

[فارسی صفحه اصلی](https://github.com/XX-net/XX-Net/wiki/Persian-home-page)


XX-Net  
=================
翻墙工具套件
* GAE proxy, 稳定、易用、快速   
* Web界面，人性化交互  


## 下载(Download)：
测试版(Test)：
https://codeload.github.com/XX-net/XX-Net/zip/2.9.4

稳定版(Stable)：
https://codeload.github.com/XX-net/XX-Net/zip/2.9.2

懒人集成浏览器版（Easy Browser Bundle）:
https://github.com/yeahwu/firefox-xx



## 链接
|   |   |
| --------   | :----  |
|使用方法：|https://github.com/XX-net/XX-Net/wiki/使用方法|
|更新历史：|https://github.com/XX-net/XX-Net/wiki/更新历史|
|问题报告:  |https://github.com/XX-net/XX-Net/issues|
|讨论群:  |https://groups.google.com/forum/#!forum/xx-net|


## 如何帮助项目
https://github.com/XX-net/XX-Net/wiki/How-to-contribute

